<?php
session_start();
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Labyrinth</title>
        <link rel="stylesheet" media="screen" href="style.css">
    </head>
    <body>
        <h1>Labyrinth</h1>
        <?php
        if(!(isset($_SESSION['aktPos']))){
            $_SESSION['aktPos'] = 0;
            $_SESSION['steps'] = 0;
            $anzT = 0;
            for($i = 0; $i < 18; $i++){
                $_SESSION['arrTreasures'][$i] = rand(0, 1);
                if($_SESSION['arrTreasures'][$i] == 1){
                    $anzT += 1;
                }
            }
            $_SESSION['treasures'] = $anzT;
            //Random Vergabe der Tore/Verbindungen
            /*  Durch einen Algorithmus werden die Eingänge random erstellt.
             *  Hierfür sind sehr viele if-Abfragen nötig um Fehler in der Map zu vermeiden
             *              */
            
            //----------------------------- REIHE 1
            
            //FELD 0 - Ausgangspunkt für die weitere Generierung der Map
            $_SESSION['randDoors'][0] = array('right' => rand(0, 1), 'down' => rand(0, 1));
            while($_SESSION['randDoors'][0]['right'] == 0 && $_SESSION['randDoors'][0]['down'] == 0){
                $_SESSION['randDoors'][0] = array('right' => rand(0, 1), 'down' => rand(0, 1));
            }
            
            if($_SESSION['randDoors'][0]['right'] == 0){
                $_SESSION['randDoors'][0]['right'] = -1;
            }else{
                $_SESSION['randDoors'][0]['right'] = 1;
            }
            if($_SESSION['randDoors'][0]['down'] == 0){
                $_SESSION['randDoors'][0]['down'] = -1;
            }else{
                $_SESSION['randDoors'][0]['down'] = 6;
            }
            
            $_SESSION['doors'][0] = array('right' => $_SESSION['randDoors'][0]['right'], 'down' => $_SESSION['randDoors'][0]['down']);
            
            //FELD 1
            $_SESSION['randDoors'][1] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            while($_SESSION['randDoors'][1]['right'] == 0 && $_SESSION['randDoors'][1]['down'] == 0){
                $_SESSION['randDoors'][1] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            }
            
            if($_SESSION['randDoors'][0]['right'] == 1){
                $_SESSION['randDoors'][1]['left'] = 0;
            }else{
                $_SESSION['randDoors'][1]['left'] = -1;
            }
            if($_SESSION['randDoors'][1]['right'] == 0){
                $_SESSION['randDoors'][1]['right'] = -1;
            }else{
                $_SESSION['randDoors'][1]['right'] = 2;
            }
            if($_SESSION['randDoors'][1]['down'] == 0){
                $_SESSION['randDoors'][1]['down'] = -1;
            }else{
                $_SESSION['randDoors'][1]['down'] = 7;
            }
            
            $_SESSION['doors'][1] = array('left' =>$_SESSION['randDoors'][1]['left'], 'right' => $_SESSION['randDoors'][1]['right'], 'down' => $_SESSION['randDoors'][1]['down']);
            
            //FELD 2
            $_SESSION['randDoors'][2] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            while($_SESSION['randDoors'][2]['right'] == 0 && $_SESSION['randDoors'][2]['down'] == 0){
                $_SESSION['randDoors'][2] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            }
            
            if($_SESSION['randDoors'][1]['right'] == 2){
                $_SESSION['randDoors'][2]['left'] = 1;
            }else{
                $_SESSION['randDoors'][2]['left'] = -1;
            }
            if($_SESSION['randDoors'][2]['right'] == 0){
                $_SESSION['randDoors'][2]['right'] = -1;
            }else{
                $_SESSION['randDoors'][2]['right'] = 3;
            }
            if($_SESSION['randDoors'][2]['down'] == 0){
                $_SESSION['randDoors'][2]['down'] = -1;
            }else{
                $_SESSION['randDoors'][2]['down'] = 8;
            }
            
            $_SESSION['doors'][2] = array('left' =>$_SESSION['randDoors'][2]['left'], 'right' => $_SESSION['randDoors'][2]['right'], 'down' => $_SESSION['randDoors'][2]['down']);
            
            //FELD 3
            $_SESSION['randDoors'][3] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            while($_SESSION['randDoors'][3]['right'] == 0 && $_SESSION['randDoors'][3]['down'] == 0){
                $_SESSION['randDoors'][3] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            }
            
            if($_SESSION['randDoors'][2]['right'] == 3){
                $_SESSION['randDoors'][3]['left'] = 2;
            }else{
                $_SESSION['randDoors'][3]['left'] = -1;
            }
            if($_SESSION['randDoors'][3]['right'] == 0){
                $_SESSION['randDoors'][3]['right'] = -1;
            }else{
                $_SESSION['randDoors'][3]['right'] = 4;
            }
            if($_SESSION['randDoors'][3]['down'] == 0){
                $_SESSION['randDoors'][3]['down'] = -1;
            }else{
                $_SESSION['randDoors'][3]['down'] = 9;
            }
            
            $_SESSION['doors'][3] = array('left' =>$_SESSION['randDoors'][3]['left'], 'right' => $_SESSION['randDoors'][3]['right'], 'down' => $_SESSION['randDoors'][3]['down']);
            
            //FELD 4
            $_SESSION['randDoors'][4] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            while($_SESSION['randDoors'][4]['right'] == 0 && $_SESSION['randDoors'][4]['down'] == 0){
                $_SESSION['randDoors'][4] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'down' => rand(0, 1));
            }
            
            if($_SESSION['randDoors'][3]['right'] == 4){
                $_SESSION['randDoors'][4]['left'] = 3;
            }else{
                $_SESSION['randDoors'][4]['left'] = -1;
            }
            if($_SESSION['randDoors'][4]['right'] == 0){
                $_SESSION['randDoors'][4]['right'] = -1;
            }else{
                $_SESSION['randDoors'][4]['right'] = 5;
            }
            if($_SESSION['randDoors'][4]['down'] == 0){
                $_SESSION['randDoors'][4]['down'] = -1;
            }else{
                $_SESSION['randDoors'][4]['down'] = 10;
            }
            
            $_SESSION['doors'][4] = array('left' =>$_SESSION['randDoors'][4]['left'], 'right' => $_SESSION['randDoors'][4]['right'], 'down' => $_SESSION['randDoors'][4]['down']);
            
            
            //FELD 5
            $_SESSION['randDoors'][5] = array('left' => rand(0, 1), 'down' => rand(0, 1));
            
            if($_SESSION['randDoors'][4]['right'] == 5){
                $_SESSION['randDoors'][5]['left'] = 4;
                if($_SESSION['randDoors'][5]['down'] == 0){
                    $_SESSION['randDoors'][5]['down'] = -1;
                }else{
                    $_SESSION['randDoors'][5]['down'] = 11;
                }
            }else{
                $_SESSION['randDoors'][5]['left'] = -1;
                $_SESSION['randDoors'][5]['down'] = 11;
            }
            
            $_SESSION['doors'][5] = array('left' =>$_SESSION['randDoors'][5]['left'], 'down' => $_SESSION['randDoors'][5]['down']);
            
            //----------------------------- REIHE 2
            
            //FELD 6
            $_SESSION['randDoors'][6] = array('right' => rand(0, 1), 'up' => rand(0, 1),'down' => rand(0, 1));
            while($_SESSION['randDoors'][6]['right'] == 0 && $_SESSION['randDoors'][6]['down'] == 0){
                $_SESSION['randDoors'][6] = array('right' => rand(0, 1), 'up' => rand(0, 1), 'down' => rand(0, 1));
            }
            if($_SESSION['randDoors'][0]['down'] == 6){
                $_SESSION['randDoors'][6]['up'] = 0;
            }else{
                $_SESSION['randDoors'][6]['up'] = -1;
            }
            if($_SESSION['randDoors'][6]['right'] == 0){
                $_SESSION['randDoors'][6]['right'] = -1;
            }else{
                $_SESSION['randDoors'][6]['right'] = 7;
            }
            if($_SESSION['randDoors'][6]['down'] == 0){
                $_SESSION['randDoors'][6]['down'] = -1;
            }else{
                $_SESSION['randDoors'][6]['down'] = 12;
            }
            
            $_SESSION['doors'][6] = array('right' =>$_SESSION['randDoors'][6]['right'],'up' =>$_SESSION['randDoors'][6]['up'], 'down' => $_SESSION['randDoors'][6]['down']);
           
            
            //FELD 7
            $_SESSION['randDoors'][7] = array('left' => rand(0, 1),'right' => rand(0, 1), 'up' => rand(0, 1),'down' => rand(0, 1));
            while($_SESSION['randDoors'][7]['right'] == 0 && $_SESSION['randDoors'][7]['down'] == 0){
                $_SESSION['randDoors'][7] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1), 'down' => rand(0, 1));
            }
            if($_SESSION['randDoors'][1]['down'] == 7){
                $_SESSION['randDoors'][7]['up'] = 1;
            }else{
                $_SESSION['randDoors'][7]['up'] = -1;
            }
            if($_SESSION['randDoors'][6]['right'] == 7){
                $_SESSION['randDoors'][7]['left'] = 6;
            }else{
                $_SESSION['randDoors'][7]['left'] = -1;
            }
            
            if($_SESSION['randDoors'][7]['right'] == 0){
                $_SESSION['randDoors'][7]['right'] = -1;
            }else{
                $_SESSION['randDoors'][7]['right'] = 8;
            }
            if($_SESSION['randDoors'][7]['down'] == 0){
                $_SESSION['randDoors'][7]['down'] = -1;
            }else{
                $_SESSION['randDoors'][7]['down'] = 13;
            }
            
            $_SESSION['doors'][7] = array('left' =>$_SESSION['randDoors'][7]['left'], 'right' =>$_SESSION['randDoors'][7]['right'],'up' =>$_SESSION['randDoors'][7]['up'], 'down' => $_SESSION['randDoors'][7]['down']);
            
            //FELD 8
            $_SESSION['randDoors'][8] = array('left' => rand(0, 1),'right' => rand(0, 1), 'up' => rand(0, 1),'down' => rand(0, 1));
            while($_SESSION['randDoors'][8]['right'] == 0 && $_SESSION['randDoors'][8]['down'] == 0){
                $_SESSION['randDoors'][8] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1), 'down' => rand(0, 1));
            }
            if($_SESSION['randDoors'][2]['down'] == 8){
                $_SESSION['randDoors'][8]['up'] = 2;
            }else{
                $_SESSION['randDoors'][8]['up'] = -1;
            }
            if($_SESSION['randDoors'][7]['right'] == 8){
                $_SESSION['randDoors'][8]['left'] = 7;
            }else{
                $_SESSION['randDoors'][8]['left'] = -1;
            }
            
            if($_SESSION['randDoors'][8]['right'] == 0){
                $_SESSION['randDoors'][8]['right'] = -1;
            }else{
                $_SESSION['randDoors'][8]['right'] = 9;
            }
            if($_SESSION['randDoors'][8]['down'] == 0){
                $_SESSION['randDoors'][8]['down'] = -1;
            }else{
                $_SESSION['randDoors'][8]['down'] = 14;
            }
            
            $_SESSION['doors'][8] = array('left' =>$_SESSION['randDoors'][8]['left'], 'right' =>$_SESSION['randDoors'][8]['right'],'up' =>$_SESSION['randDoors'][8]['up'], 'down' => $_SESSION['randDoors'][8]['down']);
            
            //FELD 9
            $_SESSION['randDoors'][9] = array('left' => rand(0, 1),'right' => rand(0, 1), 'up' => rand(0, 1),'down' => rand(0, 1));
            while($_SESSION['randDoors'][9]['right'] == 0 && $_SESSION['randDoors'][9]['down'] == 0){
                $_SESSION['randDoors'][9] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1), 'down' => rand(0, 1));
            }
            if($_SESSION['randDoors'][3]['down'] == 9){
                $_SESSION['randDoors'][9]['up'] = 3;
            }else{
                $_SESSION['randDoors'][9]['up'] = -1;
            }
            if($_SESSION['randDoors'][8]['right'] == 9){
                $_SESSION['randDoors'][9]['left'] = 8;
            }else{
                $_SESSION['randDoors'][9]['left'] = -1;
            }
            
            if($_SESSION['randDoors'][9]['right'] == 0){
                $_SESSION['randDoors'][9]['right'] = -1;
            }else{
                $_SESSION['randDoors'][9]['right'] = 10;
            }
            if($_SESSION['randDoors'][9]['down'] == 0){
                $_SESSION['randDoors'][9]['down'] = -1;
            }else{
                $_SESSION['randDoors'][9]['down'] = 15;
            }
            
            $_SESSION['doors'][9] = array('left' =>$_SESSION['randDoors'][9]['left'], 'right' =>$_SESSION['randDoors'][9]['right'],'up' =>$_SESSION['randDoors'][9]['up'], 'down' => $_SESSION['randDoors'][9]['down']);
            
            //FELD 10
            $_SESSION['randDoors'][10] = array('left' => rand(0, 1),'right' => rand(0, 1), 'up' => rand(0, 1),'down' => rand(0, 1));
            while($_SESSION['randDoors'][10]['right'] == 0 && $_SESSION['randDoors'][10]['down'] == 0){
                $_SESSION['randDoors'][10] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1), 'down' => rand(0, 1));
            }
            if($_SESSION['randDoors'][4]['down'] == 10){
                $_SESSION['randDoors'][10]['up'] = 4;
            }else{
                $_SESSION['randDoors'][10]['up'] = -1;
            }
            if($_SESSION['randDoors'][9]['right'] == 10){
                $_SESSION['randDoors'][10]['left'] = 9;
            }else{
                $_SESSION['randDoors'][10]['left'] = -1;
            }
            
            if($_SESSION['randDoors'][10]['right'] == 0){
                $_SESSION['randDoors'][10]['right'] = -1;
            }else{
                $_SESSION['randDoors'][10]['right'] = 11;
            }
            if($_SESSION['randDoors'][10]['down'] == 0){
                $_SESSION['randDoors'][10]['down'] = -1;
            }else{
                $_SESSION['randDoors'][10]['down'] = 16;
            }
            
            $_SESSION['doors'][10] = array('left' =>$_SESSION['randDoors'][10]['left'], 'right' =>$_SESSION['randDoors'][10]['right'],'up' =>$_SESSION['randDoors'][10]['up'], 'down' => $_SESSION['randDoors'][10]['down']);
          
            
            //FELD 11
            $_SESSION['randDoors'][11] = array('left' => rand(0, 1), 'up' => rand(0, 1),'down' => rand(0, 1));
            if($_SESSION['randDoors'][5]['down'] == 11){
                $_SESSION['randDoors'][11]['up'] = 5;
            }else{
                $_SESSION['randDoors'][11]['up'] = -1;
            }
            if($_SESSION['randDoors'][10]['right'] == 11){
                $_SESSION['randDoors'][11]['left'] = 10;
                if($_SESSION['randDoors'][11]['down'] == 0){
                    $_SESSION['randDoors'][11]['down'] = -1;
                }else{
                    $_SESSION['randDoors'][11]['down'] = 16;
                }
            }else{
                $_SESSION['randDoors'][11]['left'] = -1;
                $_SESSION['randDoors'][11]['down'] = 16;
            }
            
            $_SESSION['doors'][11] = array('left' =>$_SESSION['randDoors'][11]['left'],'up' =>$_SESSION['randDoors'][11]['up'], 'down' => $_SESSION['randDoors'][11]['down']);
            
            //----------------------------- REIHE 3
            
             //FELD 12
            $_SESSION['randDoors'][12] = array('right' => rand(0, 1), 'up' => rand(0, 1));
            if($_SESSION['randDoors'][6]['down'] == 12){
                $_SESSION['randDoors'][12]['up'] = 6;
            }else{
                $_SESSION['randDoors'][12]['up'] = -1;
            }
            if($_SESSION['randDoors'][12]['right'] == 0){
                $_SESSION['randDoors'][12]['right'] = -1;
            }else{
                $_SESSION['randDoors'][12]['right'] = 13;
            }         
            $_SESSION['doors'][12] = array('up' =>$_SESSION['randDoors'][12]['up'], 'right' => $_SESSION['randDoors'][12]['right']);
            
            //FELD 13
            $_SESSION['randDoors'][13] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1));
            
            if($_SESSION['randDoors'][12]['right'] == 13){
                $_SESSION['randDoors'][13]['left'] = 12;
            }else{
                $_SESSION['randDoors'][13]['left'] = -1;
            }
            if($_SESSION['randDoors'][7]['down'] == 13){
                $_SESSION['randDoors'][13]['up'] = 7;
            }else{
                $_SESSION['randDoors'][13]['up'] = -1;
            }
            if($_SESSION['randDoors'][13]['up'] == -1 && $_SESSION['randDoors'][13]['left'] == -1){
                $_SESSION['randDoors'][13]['right'] = 14;
            }else{
                if($_SESSION['randDoors'][13]['right'] == 0){
                    $_SESSION['randDoors'][13]['right'] = -1;
                }else{
                    $_SESSION['randDoors'][13]['right'] = 14;
                }
            }
            
            $_SESSION['doors'][13] = array('left' =>$_SESSION['randDoors'][13]['left'], 'right' => $_SESSION['randDoors'][13]['right'], 'up' => $_SESSION['randDoors'][13]['up']);
            
             //FELD 14
            $_SESSION['randDoors'][14] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1));
            
            if($_SESSION['randDoors'][13]['right'] == 14){
                $_SESSION['randDoors'][14]['left'] = 13;
            }else{
                $_SESSION['randDoors'][14]['left'] = -1;
            }
            if($_SESSION['randDoors'][8]['down'] == 14){
                $_SESSION['randDoors'][14]['up'] = 8;
            }else{
                $_SESSION['randDoors'][14]['up'] = -1;
            }
            if($_SESSION['randDoors'][14]['up'] == -1 && $_SESSION['randDoors'][14]['left'] == -1){
                $_SESSION['randDoors'][14]['right'] = 15;
            }else{
                if($_SESSION['randDoors'][14]['right'] == 0){
                    $_SESSION['randDoors'][14]['right'] = -1;
                }else{
                    $_SESSION['randDoors'][14]['right'] = 15;
                }
            }
            
            $_SESSION['doors'][14] = array('left' =>$_SESSION['randDoors'][14]['left'], 'right' => $_SESSION['randDoors'][14]['right'], 'up' => $_SESSION['randDoors'][14]['up']);
            
            
             //FELD 15
            $_SESSION['randDoors'][15] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1));
            
            if($_SESSION['randDoors'][14]['right'] == 15){
                $_SESSION['randDoors'][15]['left'] = 14;
            }else{
                $_SESSION['randDoors'][15]['left'] = -1;
            }
            if($_SESSION['randDoors'][9]['down'] == 15){
                $_SESSION['randDoors'][15]['up'] = 9;
            }else{
                $_SESSION['randDoors'][15]['up'] = -1;
            }
            if($_SESSION['randDoors'][15]['up'] == -1 && $_SESSION['randDoors'][15]['left'] == -1){
                $_SESSION['randDoors'][15]['right'] = 16;
            }else{
                if($_SESSION['randDoors'][15]['right'] == 0){
                    $_SESSION['randDoors'][15]['right'] = -1;
                }else{
                    $_SESSION['randDoors'][15]['right'] = 16;
                }
            }
            
            $_SESSION['doors'][15] = array('left' =>$_SESSION['randDoors'][15]['left'], 'right' => $_SESSION['randDoors'][15]['right'], 'up' => $_SESSION['randDoors'][15]['up']);
            
            //FELD 16
            $_SESSION['randDoors'][16] = array('left' => rand(0, 1), 'right' => rand(0, 1), 'up' => rand(0, 1));
            
            if($_SESSION['randDoors'][15]['right'] == 16){
                $_SESSION['randDoors'][16]['left'] = 15;
            }else{
                $_SESSION['randDoors'][16]['left'] = -1;
            }
            if($_SESSION['randDoors'][10]['down'] == 16){
                $_SESSION['randDoors'][16]['up'] = 10;
            }else{
                $_SESSION['randDoors'][16]['up'] = -1;
            }
            if($_SESSION['randDoors'][16]['up'] == -1 && $_SESSION['randDoors'][16]['left'] == -1){
                $_SESSION['randDoors'][16]['right'] = 17;
            }else{
                if($_SESSION['randDoors'][16]['right'] == 0){
                    $_SESSION['randDoors'][16]['right'] = -1;
                }else{
                    $_SESSION['randDoors'][16]['right'] = 17;
                }
            }
            
            $_SESSION['doors'][16] = array('left' =>$_SESSION['randDoors'][16]['left'], 'right' => $_SESSION['randDoors'][16]['right'], 'up' => $_SESSION['randDoors'][16]['up']);
            
            //FELD 17
            $_SESSION['randDoors'][17] = array('left' => rand(0, 1), 'up' => rand(0, 1));
            
            if($_SESSION['randDoors'][16]['right'] == 17){
                $_SESSION['randDoors'][17]['left'] = 16;
            }else{
                $_SESSION['randDoors'][17]['left'] = -1;
            }
            if($_SESSION['randDoors'][11]['down'] == 17){
                $_SESSION['randDoors'][17]['up'] = 11;
            }else{
                $_SESSION['randDoors'][17]['up'] = -1;
            }
            
            $_SESSION['doors'][17] = array('left' =>$_SESSION['randDoors'][17]['left'], 'up' => $_SESSION['randDoors'][17]['up']);
            
            
        $_SESSION['map'][0] = array('schatz' => $_SESSION['arrTreasures'][0], 'left' => -1, 'up' => -1, 'right' => $_SESSION['doors'][0]['right'], 'down' => $_SESSION['doors'][0]['down']);
        $_SESSION['map'][1] = array('schatz' => $_SESSION['arrTreasures'][1], 'left' => $_SESSION['doors'][1]['left'], 'up' => -1, 'right' => $_SESSION['doors'][1]['right'], 'down' => $_SESSION['doors'][1]['down']);
        $_SESSION['map'][2] = array('schatz' => $_SESSION['arrTreasures'][2], 'left' => $_SESSION['doors'][2]['left'], 'up' => -1, 'right' => $_SESSION['doors'][2]['right'], 'down' => $_SESSION['doors'][2]['down']);
        $_SESSION['map'][3] = array('schatz' => $_SESSION['arrTreasures'][3], 'left' => $_SESSION['doors'][3]['left'], 'up' => -1, 'right' => $_SESSION['doors'][3]['right'], 'down' => $_SESSION['doors'][3]['down']);
        $_SESSION['map'][4] = array('schatz' => $_SESSION['arrTreasures'][4], 'left' => $_SESSION['doors'][4]['left'], 'up' => -1, 'right' => $_SESSION['doors'][4]['right'], 'down' => $_SESSION['doors'][4]['down']);
        $_SESSION['map'][5] = array('schatz' => $_SESSION['arrTreasures'][5], 'left' => $_SESSION['doors'][5]['left'], 'up' => -1, 'right' => -1, 'down' => $_SESSION['doors'][5]['down']);
        
        $_SESSION['map'][6] = array('schatz' => $_SESSION['arrTreasures'][6], 'left' => -1, 'up' => $_SESSION['doors'][6]['up'], 'right' => $_SESSION['doors'][6]['right'], 'down' => $_SESSION['doors'][6]['down']);
        $_SESSION['map'][7] = array('schatz' => $_SESSION['arrTreasures'][7], 'left' => $_SESSION['doors'][7]['left'], 'up' => $_SESSION['doors'][7]['up'], 'right' => $_SESSION['doors'][7]['right'], 'down' => $_SESSION['doors'][7]['down']);
        $_SESSION['map'][8] = array('schatz' => $_SESSION['arrTreasures'][8], 'left' => $_SESSION['doors'][8]['left'], 'up' => $_SESSION['doors'][8]['up'], 'right' => $_SESSION['doors'][8]['right'], 'down' => $_SESSION['doors'][8]['down']);
        $_SESSION['map'][9] = array('schatz' => $_SESSION['arrTreasures'][9], 'left' => $_SESSION['doors'][9]['left'], 'up' => $_SESSION['doors'][9]['up'], 'right' => $_SESSION['doors'][9]['right'], 'down' => $_SESSION['doors'][7]['down']);
        $_SESSION['map'][10] = array('schatz' => $_SESSION['arrTreasures'][10], 'left' => $_SESSION['doors'][10]['left'], 'up' => $_SESSION['doors'][10]['up'], 'right' => $_SESSION['doors'][10]['right'], 'down' => $_SESSION['doors'][10]['down']);
        $_SESSION['map'][11] = array('schatz' => $_SESSION['arrTreasures'][11], 'left' => $_SESSION['doors'][11]['left'], 'up' => $_SESSION['doors'][11]['up'], 'right' => -1, 'down' => $_SESSION['doors'][11]['down']);
        
        $_SESSION['map'][12] = array('schatz' => $_SESSION['arrTreasures'][12], 'left' => -1, 'up' => $_SESSION['doors'][12]['up'], 'right' => $_SESSION['doors'][12]['right'], 'down' => -1);
        $_SESSION['map'][13] = array('schatz' => $_SESSION['arrTreasures'][13], 'left' => $_SESSION['doors'][13]['left'], 'up' => $_SESSION['doors'][13]['up'], 'right' => $_SESSION['doors'][13]['right'], 'down' => -1);
        $_SESSION['map'][14] = array('schatz' => $_SESSION['arrTreasures'][14], 'left' => $_SESSION['doors'][14]['left'], 'up' => $_SESSION['doors'][14]['up'], 'right' => $_SESSION['doors'][14]['right'], 'down' => -1);
        $_SESSION['map'][15] = array('schatz' => $_SESSION['arrTreasures'][15], 'left' => $_SESSION['doors'][15]['left'], 'up' => $_SESSION['doors'][15]['up'], 'right' => $_SESSION['doors'][15]['right'], 'down' => -1);
        $_SESSION['map'][16] = array('schatz' => $_SESSION['arrTreasures'][16], 'left' => $_SESSION['doors'][16]['left'], 'up' => $_SESSION['doors'][16]['up'], 'right' => $_SESSION['doors'][16]['right'], 'down' => -1);
        $_SESSION['map'][17] = array('schatz' => $_SESSION['arrTreasures'][17], 'left' => $_SESSION['doors'][17]['left'], 'up' => $_SESSION['doors'][17]['up'], 'right' => -1, 'down' => -1);
        }else{      //AUSWERTUNG DER BUTTON INPUTS
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
            if(isset($_POST['up'])){
                $_SESSION['aktPos'] = $_SESSION['map'][$_SESSION['aktPos']]['up'];
            }
            if(isset($_POST['left'])){
                $_SESSION['aktPos'] = $_SESSION['map'][$_SESSION['aktPos']]['left'];
            }
            if(isset($_POST['right'])){
                $_SESSION['aktPos'] = $_SESSION['map'][$_SESSION['aktPos']]['right'];
            }
            if(isset($_POST['down'])){
               $_SESSION['aktPos'] = $_SESSION['map'][$_SESSION['aktPos']]['down'];
            }
            if(isset($_POST['restart'])){
               echo "Spiel neustarten?";
               session_unset();
               session_destroy(); 
            }
            }
            if($_SESSION['aktPos'] == -1){
                echo "Sie haben versucht zu schummeln! Starten Sie das Spiel erneut.";
                session_unset();
                session_destroy(); 
            }
            
            if($_SESSION['map'][$_SESSION['aktPos']]['schatz'] == true){
                $_SESSION['treasures'] -= 1;
                $_SESSION['map'][$_SESSION['aktPos']]['schatz'] = false;
                echo "<h5>","Herzlichen Glückwunsch! Sie haben einen Schatz gefunden!","</h5>", "<br>";
            }
            
            $_SESSION['steps'] += 1;
            
            if($_SESSION['treasures'] == 0 && isset($_SESSION['treasures'])){
                echo "Herzlichen Glückwunsch, sie haben das Spiel geschafft!";
                session_unset();
                session_destroy(); 
            }
        }
        
        if(isset($_SESSION['treasures']) && isset($_SESSION['steps'])){
        echo "Sie haben: ", $_SESSION['treasures'] , " Schätze übrig", "<br>";
        echo "Sie sind: ", $_SESSION['steps'], " Schritte gegangen", "<br>";
        }
       ?><form method="post"><?php
       if(isset($_SESSION['aktPos'])){
        if($_SESSION['map'][$_SESSION['aktPos']]['up'] == -1){?>
            <button type="submit" name="up" disabled="disabled" class="off">^</button>
        <?php
        }else{?>
           <button type="submit" name="up">^</button>
        <?php
        }
        if($_SESSION['map'][$_SESSION['aktPos']]['left'] == -1){?>
             <button type="submit" name="left" disabled="disabled" class="off"><</button>
        <?php
        }else{?>
            <button type="submit" name="left"><</button>
        <?php
        }
        if($_SESSION['map'][$_SESSION['aktPos']]['right'] == -1){?>
            <button type="submit" name="right" disabled="disabled" class="off">></button>
        <?php
        }else{?>
            <button type="submit" name="right">></button>
        <?php
        }
        if($_SESSION['map'][$_SESSION['aktPos']]['down'] == -1){?>
             <button type="submit" name="down" disabled="disabled" class="off">v</button>
        <?php
        }else{?>
                 <button type="submit" name="down">v</button>
        <?php
        }
       }?>
                 <button type="submit" name="restart" >Restart</button>
       </form>
    </body>
</html>
