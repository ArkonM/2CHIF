
  <?php
    mysql_connect("localhost", "scwread", "read") or die("Error connecting to database: ".mysql_error());

    mysql_select_db("scw") or die(mysql_error());
?>

<!DOCTYPE html>
<html>
<head>
<title>Search</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="styles.css">
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
</head>
<body>
  <?php
  $result = mysql_query("SELECT Name FROM Country");
  $alle_eintraege=Array();
  while($daten=mysql_fetch_assoc($result))
  {
      $alle_eintraege[]=$daten;
  }
//----------------------------------------------------------- Daten auslesen
    ?>
  <form method="POST">
    <center><div class="mySelect">
      <select name="country">
      <?php
      foreach($alle_eintraege as $value){
          foreach($value as $erg){
            echo  "<option value='".$erg."'>".$erg."</option>";
          }
      }
      ?>
    </select>
  </div></center>
    <br><br>
    <center><input class="btn" type="submit"></center>

  </form>
  <?php
//----------------------------------------------------------- Ergebnis Ausgabe
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $query = $_POST["country"];
    $min_length = 1;
    if(strlen($query) >= $min_length){
        $query = htmlspecialchars($query);
        $query = mysql_real_escape_string($query);
        $raw_results = mysql_query("SELECT * FROM Country WHERE (`Name` LIKE '%".$query."%')") or die(mysql_error());
        $allData=Array();
        $info = array("Name", "ISO-Code", "Hauptstadt", "Provinz der Hauptstadt", "Flaeche", "Einwohner");
        $i = 0;

        while($data=mysql_fetch_assoc($raw_results))
        {
            $isoCode = $data['Code'];
            $allData[]=$data;
        }
        foreach($allData as $value){
            foreach($value as $erg){
              if($erg != NULL){
                if($i == 4){
                  echo "<h5>".$info[$i]."</h5>"."<p>".$erg." km<sup>2</sup>"."</p>";
                }else{
                  echo "<h5>".$info[$i]."</h5>"."<p>".$erg."</p>";
                }
              }
              $i += 1;
            }
        }
        //Read Federal States
        $query = $isoCode;
        $min_length = 1;
        if(strlen($query) >= $min_length){
            $raw_results = mysql_query("SELECT Name FROM Language WHERE `Country` = '$isoCode'") or die(mysql_error());
            $allData=Array();

            while($data=mysql_fetch_assoc($raw_results))
            {
                $allData[]=$data;
            }
            if(mysql_num_rows($raw_results)>=1){
            echo "<h5>"."Amtssprache(n)"."</h5>";
            foreach($allData as $value){
                foreach($value as $erg){
                  if($erg != NULL){
                    echo "<p>".$erg."</p>";
                  }
                }
            }
          }
        }
      //Ethnische Gruppen
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Name FROM EthnicGroup WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Ethnische Gruppe(n)"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Borders
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Country2 FROM borders WHERE `Country1` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Nachbarla(e)nd(er)"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Deserts
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Desert FROM geo_Desert WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Wüsten des Landes"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Cities//Deserts
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Name FROM City WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Wichtigste(n) Sta(e)dt(e) des Landes"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Lakes
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Lake FROM geo_Lake WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."See(n) des Landes"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Mountains
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Mountain FROM geo_Mountain WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Berg(e)"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //River
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT River FROM geo_River WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Flu(e)ss(e) des Landes"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Organizations
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Organization FROM isMember WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Organisationen und Vereinigungen"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Politics
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT Government FROM Politics WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Regierungsform"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."</p>";
                }
              }
          }
        }
      }
      //Economy
      if(strlen($query) >= $min_length){
          $raw_results = mysql_query("SELECT GDP FROM Economy WHERE `Country` = '$isoCode'") or die(mysql_error());
          $allData=Array();

          while($data=mysql_fetch_assoc($raw_results))
          {
              $allData[]=$data;
          }
          if(mysql_num_rows($raw_results)>=1){
          echo "<h5>"."Bruttoinlandsprodukt in Dollar"."</h5>";
          foreach($allData as $value){
              foreach($value as $erg){
                if($erg != NULL){
                  echo "<p>".$erg."$</p>";
                }
              }
          }
        }
      }
      //---------------------Output of other stuff  #ComingSoon


    }
}
  ?>

</body>

</html>
